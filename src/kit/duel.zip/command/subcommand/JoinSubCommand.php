<?php

namespace duel\command\subcommand;

use pocketmine\command\CommandSender;
use pocketmine\level\particle\DustParticle;
use pocketmine\Player;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;
use duel\command\DuelCommand;
use duel\command\SubCommand;
use duel\Loader;

class JoinSubCommand extends SubCommand {

    const PREFIX = TF::GRAY . "[" . TF::AQUA . "Duel" . TF::GRAY . "] ";

    private static $pos1 = null;
    private static $pos2 = null;

    private $command;
    private static $config;

    public function __construct(DuelCommand $command) {
        $this->command = $command;
        $file = Loader::getInstance()->getDataFolder() . "join.yml";
        self::$config = new Config($file, Config::YAML);
        $level = Loader::getInstance()->getServer()->getDefaultLevel();
        if (self::$config->exists("pos1")) {
            $data = self::$config->get("pos1");
            self::$pos1 = new Position($data["x"], $data["y"], $data["z"], $level);
        }
        if (self::$config->exists("pos2")) {
            $data = self::$config->get("pos2");
            self::$pos2 = new Position($data["x"], $data["y"], $data["z"], $level);
        }
    }

    public function execute(CommandSender $sender, array $args) {
        if (!$sender instanceof Player) {
            $sender->sendMessage("Use este comando en el juego.");
            return;
        }
        if (count($args) < 2) {
            $sender->sendMessage(self::PREFIX . " Use: /duel join pos1 | pos2");
            return;
        }
        switch (strtolower($args[1])) {
            case "pos1":
                self::$pos1 = $sender->getPosition();
                self::$config->set("pos1", [
                    "x" => self::$pos1->x,
                    "y" => self::$pos1->y,
                    "z" => self::$pos1->z
                ]);
                self::$config->save();
                $sender->sendMessage(self::PREFIX . "Posicion 1 establecida.");
                break;
            case "pos2":
                self::$pos2 = $sender->getPosition();
                self::$config->set("pos2", [
                    "x" => self::$pos2->x,
                    "y" => self::$pos2->y,
                    "z" => self::$pos2->z
                ]);
                self::$config->save();
                $sender->sendMessage(self::PREFIX . "Posicion 2 establecida.");
                break;
            default:
                $sender->sendMessage(self::PREFIX . " Use: /duel join pos1 | pos2");
                break;
        }
    }

    public static function checkPlayers() {
        if (self::$pos1 === null || self::$pos2 === null) return;
        $world = self::$pos1->getLevel();
        if ($world === null) return;
        $arenaAvailable = Loader::getInstance()->emptyArenaChooser->getRandomArena() !== null;
        $color = $arenaAvailable ? [0, 255, 0] : [100, 100, 100];
        self::spawnCircle(self::$pos1, $color);
        self::spawnCircle(self::$pos2, $color);
        $players1 = [];
        $players2 = [];
        foreach ($world->getPlayers() as $player) {
            if (self::isInside($player, self::$pos1, 2)) {
                $players1[] = $player;
            }
            if (self::isInside($player, self::$pos2, 2)) {
                $players2[] = $player;
            }
        }
        if (count($players1) === 1 && count($players2) === 1 && $arenaAvailable) {
            $p1 = $players1[0];
            $p2 = $players2[0];
            $p1->sendMessage("§a¡Duelo iniciado contra " . $p2->getName() . "!");
            $p2->sendMessage("§a¡Duelo iniciado contra " . $p1->getName() . "!");
            $arena = Loader::getInstance()->emptyArenaChooser->getRandomArena();
            if ($arena === null) {
                $p1->sendMessage('§r§eDuel: §r§c¡No se encontro ninguna arena disponible!');
                $p2->sendMessage('§r§eDuel: §r§c¡No se encontro ninguna arena disponible!');
                return;
            }
            $arena->join($p1);
            $arena->join($p2);
            self::$pos1 = null;
            self::$pos2 = null;
        }
    }

    private static function isInside(Player $player, Position $pos, float $radius) {
        return $player->distance($pos) <= $radius;
    }

    private static function spawnCircle(Position $center, array $rgb) {
        $radius = 2;
        $particles = 12;
        $level = $center->getLevel();
        if ($level === null) return;
        for ($i = 0; $i < $particles; $i++) {
            $angle = deg2rad($i * (360 / $particles));
            $x = $center->x + $radius * cos($angle);
            $z = $center->z + $radius * sin($angle);
            $y = $center->y;
            $particle = new DustParticle(new Vector3($x, $y + 0.2, $z), $rgb[0], $rgb[1], $rgb[2], 1);
            $level->addParticle($particle);
        }
    }

    public static function clearPositions() {
        self::$pos1 = null;
        self::$pos2 = null;
    }
    
    public static function refreshParticles() {
        if (self::$pos1 !== null) {
            self::spawnCircle(self::$pos1, [0, 255, 0]);
        }
        if (self::$pos2 !== null) {
            self::spawnCircle(self::$pos2, [0, 255, 0]);
        }
    }
}