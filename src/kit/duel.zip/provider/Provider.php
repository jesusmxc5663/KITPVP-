<?php

namespace duel\provider;

interface Provider
{
	
	public function load();
}